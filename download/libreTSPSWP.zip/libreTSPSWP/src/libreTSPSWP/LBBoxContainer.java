package libreTSPSWP;

public class LBBoxContainer {
	public LBBox[] bboxes;
	public int nBBoxes;
	
}

