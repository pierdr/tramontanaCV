package tramontanaCV;

public class BVector{
	public int x;
	public int y;
	public BVector(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
}
