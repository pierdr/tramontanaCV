package tramontanaCV;

public class LBBoxContainer {
	public LBBox[] bboxes;
	public int nBBoxes;
	
}

