package tramontanaCV;

public class LBlobsContainer {
	public LBlob[] blobs;
	public int nBlobs;
	
}
