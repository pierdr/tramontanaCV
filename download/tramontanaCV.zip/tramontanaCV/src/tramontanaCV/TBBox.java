package tramontanaCV;

public class TBBox {
	public float x;
	public float y;
	public float w;
	public float h;
	
	public TBBox(int x, int y, int w, int h)
	{
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
	}
	public TBBox(float x, float y, float w, float h)
	{
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
	}
}
