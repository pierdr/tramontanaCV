package tramontanaCV;

public class TBBoxContainer {
	public TBBox[] bboxes;
	public int nBBoxes;
	
}

