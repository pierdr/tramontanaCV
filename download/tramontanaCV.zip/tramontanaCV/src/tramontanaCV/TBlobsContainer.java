package tramontanaCV;

public class TBlobsContainer {
	public TBlob[] blobs;
	public int nBlobs;
	
}
