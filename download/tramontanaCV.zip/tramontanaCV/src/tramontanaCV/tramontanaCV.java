package tramontanaCV;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URI;
import java.util.concurrent.CountDownLatch;

import org.eclipse.jetty.websocket.api.Session;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketConnect;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketError;
import org.eclipse.jetty.websocket.api.annotations.OnWebSocketMessage;
import org.eclipse.jetty.websocket.api.annotations.WebSocket;
import org.eclipse.jetty.websocket.client.ClientUpgradeRequest;
import org.eclipse.jetty.websocket.client.WebSocketClient;

import tramontanaCV.TBlob;
import processing.core.PApplet;
import processing.data.JSONArray;
import processing.data.JSONObject;
import java.util.ArrayList;
import tramontanaCV.TVector;
/**
 * 
 * 
 * 
 * 
 */


@WebSocket
public class tramontanaCV {
	//WEBSOCKET UTILS
	private Session session;
	CountDownLatch latch = new CountDownLatch(1);
	public boolean isOpen;
	private WebSocketClient client;
	private String ipAddress;
	private JSONObject workingJson;
	private int port;
	
	
	//SKETCH REFRENCE
	PApplet sketch;
	
	
	//RETRIEVING MESSAGE
	private int index;
	private Method onBoundingBoxReceived;
	private Method onBlobsReceived;
	private Method onFrameReceived;
	private Method onFacesReceived;
	
	//UTILS
	public boolean isVerbose = false;
	
	
	public tramontanaCV(PApplet parent,String IP){
		sketch = parent;
		ipAddress = IP;
		port = 9088;
		
		//LOOK FOR METHODS
		try {
			Class<?> params[] = new Class[3];
			params[0] = TBBoxContainer.class;
			params[1] = int.class;
			params[2] = String.class;
			
			onBoundingBoxReceived = parent.getClass().getMethod("onBoundingBoxReceived", params);
        } catch (Exception e) {
        		
        		printLog("Method onBoundingBoxReceived not found.");
        }
		try {
			Class<?> params[] = new Class[3];
			params[0] = TBlobsContainer.class;
			params[1] = int.class;
			params[2] = String.class;
			
			onBlobsReceived = parent.getClass().getMethod("onBlobsReceived", params);
        } catch (Exception e) {
        		
        		printLog("Method onBlobsReceived not found.");
        }
		//ON FACE RECEIVED
		try {
			Class<?> params[] = new Class[3];
			params[0] = TBBoxContainer.class;
			params[1] = int.class;
			params[2] = String.class;
			
			onFacesReceived = parent.getClass().getMethod("onFacesReceived", params);
        } catch (Exception e) {
        		
        		printLog("Method onFacesReceived not found.");
        }
		//ON FRAME RECEIVED
		try {
			Class<?> params[] = new Class[2];
			params[0] = processing.core.PImage.class;
			params[1] = String.class;
			
			onFrameReceived = parent.getClass().getMethod("onFrameReceived", params);
        } catch (Exception e) {
        		
        		printLog("Method onFrameReceived not found.");
        }
		
		/* WEBSOCKET START */
		connectToSocket("ws://"+IP+":"+port);
		
	}
//	public tramontanaCV(PApplet parent,String IP,int Port)
//	{
//		this(parent,IP);
//		this.port = Port;
//		
//	}
	private void connectToSocket(String endpointURI) {
		client = new WebSocketClient();
		try {
			client.start();
			URI echoUri = new URI(endpointURI);
			ClientUpgradeRequest request = new ClientUpgradeRequest();
			client.connect(this, echoUri, request);
			this.getLatch().await();
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}
	
	/**
	 * 
	 * Control tramontanaCV from Processing
	 * 
	 */
	public void lockExposure(){
		this.sendMessage("{\"m\":\"lockAE\"}");
	}
	public void unlockExposure() {
		this.sendMessage("{\"m\":\"unlockAE\"}");
	}
	public void captureBackground() {
		this.sendMessage("{\"m\":\"captureBg\"}");
	}
	public void setBlur(float amount){
		if(amount>=0 && amount<=1.0)
		{
			this.sendMessage("{\"m\":\"blur\",\"val\":"+amount+"}");
		}
		else
		{
			System.out.println("Blur amount out of bounds. Shoud be between [0.0 .. 1.0].");
		}
	}
	public void setThreshold(int amount)	{
		if(amount>=0 && amount<=255)
		{
			this.sendMessage("{\"m\":\"threshold\",\"val\":"+amount+"}");
		}
		else
		{
			System.out.println("Blur amount out of bounds. Shoud be between [0 .. 255].");
		}
	}
	public void setBlobs(int min, int max, int num){
		this.sendMessage("{\"m\":\"blobs\",\"max\":"+max+",\"min\":"+min+",\"num\":"+num+"}");
	}
	public void takeScreenshot()	{
		this.sendMessage("{\"m\":\"save\"}");
	}
	public void setCamera(int cameraId) {//0 for back camera, 1 for front camera
		this.sendMessage("{\"m\":\"cam\",\"id\":"+cameraId+"}");
	}
	public void switchToDetectFaces()	{
		this.sendMessage("{\"m\":\"mFac\"}");
	}
	public void switchToDetectBlobs()	{
		this.sendMessage("{\"m\":\"mCV\"}");
	}
	
	
	/**
	 * 
	 * Sending incoming messages to the Processing sketch's websocket event function 
	 * 
	 * @param session The connection between server and client
	 * @param message The received message
	 * @throws IOException If no event fonction is registered in the Processing sketch then an exception is thrown, but it will be ignored
	 */
	@OnWebSocketMessage
	public void onText(Session session, String message) throws IOException {
		try {
			workingJson = sketch.parseJSONObject(message);
		}catch(Exception e)
		{
			printLog("incorrect JSON: "+e);
			return;
		}
		String event = (String) workingJson.get("m");
		
		if(event.contains("x") || event.contains("f")) 
		{
			
			//RECEIVED BOUNDING BOX
			JSONArray a = new JSONArray();
			
			try {
				a = workingJson.getJSONArray("a");
			}catch(Exception e){
				printLog("Error in parsing Bounding boxes; \n "+e);
			}
		
			try {
				
				TBBoxContainer container = new TBBoxContainer();
				container.bboxes = new TBBox[a.size()];
				container.nBBoxes = a.size();
				
					for(index=0;index<a.size();index+=1)
					{
						
						JSONArray b = a.getJSONArray(index);
						if(event.contains("x"))
						container.bboxes[index] = new TBBox(b.getInt(0),b.getInt(1),b.getInt(2),b.getInt(3));
						if(event.contains("f"))
						container.bboxes[index] = new TBBox(b.getFloat(0),b.getFloat(1),b.getFloat(2),b.getFloat(3));
					}
				
				try {
					if(event.contains("x"))
					{
						onBoundingBoxReceived.invoke(sketch,container,(int)a.size(),ipAddress);
					}
					else if(event.contains("f"))
					{
						onFacesReceived.invoke(sketch, container,(int)a.size(),ipAddress);
					}
				}
				catch(Exception e)
				{
					printLog("invoke onBoundingBoxReceived or onFacesReceived error: "+e);
				}
			}
			catch(Exception e)
			{
				printLog("processing bounding box resulted in an error "+e);
			}
		}
		else if(event.contains("b")) 
		{
			//RECEIVED BLOBS
			JSONArray a = new JSONArray();
			
			try {
				a = workingJson.getJSONArray("a");
			}catch(Exception e){
				printLog("parse error "+e);
			}
			
			try {
				
				LBlobsContainer container = new LBlobsContainer();
				container.blobs = new LBlob[a.size()];
				container.nBlobs = a.size();
				
					for(index=0;index<a.size();index+=1)
					{
						container.blobs[index] = new LBlob(sketch);
						JSONArray b = a.getJSONArray(index);
						container.blobs[index].pts = new BVector[(int)b.size()/2];
						container.blobs[index].nPts = b.size()/2;
						for(int i=0;i<b.size()/2;i++)
						{
							container.blobs[index].pts[i] = new BVector(b.getInt((int)i*2),b.getInt((int)(i*2)+1));
						}
					}
				
				try {
					onBlobsReceived.invoke(sketch, container, container.nBlobs ,ipAddress);
				}
				catch(Exception e)
				{
					printLog("invoke error: blobs should have been received and parsed but "+e);
				}
			}
			catch(Exception e)
			{
				printLog("processing blobs resulted in an error: "+e);
			}
			
		}
	}
	
	private void printLog(String s)
	{
		if(isVerbose) {
			System.out.println(s);
		}
	}
	
	
	/**
	 * 
	 * Handling establishment of the connection
	 * 
	 * @param session The connection between server and client
	 */
	@OnWebSocketConnect
	public void onConnect(Session session) {
		this.session = session;
		latch.countDown();
		isOpen = true;
		printLog("connection open");
	}

	/**
	 * 
	 * Sends message to the websocket server
	 * 
	 * @param str The message to send to the server
	 */
	private void sendMessage(String str) {
		try {
			session.getRemote().sendString(str);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * Handles errors occurring and writing them to the console 
	 * 
	 * @param cause The cause of an error
	 */
	@OnWebSocketError
	public void onError(Throwable cause) {
		System.out.printf("onError(%s: %s)%n",cause.getClass().getSimpleName(), cause.getMessage());
		cause.printStackTrace(System.out);
		isOpen = false;
	}

	private CountDownLatch getLatch() {
		return latch;
	}
}
